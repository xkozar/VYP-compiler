#!/bin/bash
export PYTHONPATH=$PYTHONPATH:/pub/courses/vyp/antlr4-python3-runtime-4.8/src/
python3 src/main.py "$@"
